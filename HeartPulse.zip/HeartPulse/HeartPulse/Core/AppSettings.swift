import SwiftUI

enum SettingsKeys {
    static let language = "settings.language"
    static let appearance = "settings.appearance"
    static let onboarded = "settings.onboarded"
    static let highOn = "alert.high.on"
    static let highValue = "alert.high.value"
    static let lowOn = "alert.low.on"
    static let lowValue = "alert.low.value"
    static let reminderOn = "alert.reminder.on"
    static let reminderHour = "alert.reminder.hour"
    static let reminderMinute = "alert.reminder.minute"
    static let summaryOn = "alert.summary.on"
    static let summaryHour = "alert.summary.hour"
    static let summaryMinute = "alert.summary.minute"
    static let lastAlertCheck = "alert.lastCheck"
    static let lastAlertDate = "alert.lastAlert"

    static func registerDefaults() {
        UserDefaults.standard.register(defaults: [
            language: "system", appearance: "system", onboarded: false,
            highOn: false, highValue: 120, lowOn: false, lowValue: 40,
            reminderOn: false, reminderHour: 9, reminderMinute: 0,
            summaryOn: false, summaryHour: 21, summaryMinute: 0
        ])
    }
}

/// In-app language lookup so Arabic/English can be switched without changing the system language.
enum Loc {
    static var languageCode: String {
        let pref = UserDefaults.standard.string(forKey: SettingsKeys.language) ?? "system"
        if pref == "en" || pref == "ar" { return pref }
        return Locale.preferredLanguages.first?.hasPrefix("ar") == true ? "ar" : "en"
    }

    static func t(_ key: String, _ args: [CVarArg] = []) -> String {
        let code = languageCode
        let bundle = Bundle.main.path(forResource: code, ofType: "lproj").flatMap(Bundle.init(path:)) ?? .main
        let format = bundle.localizedString(forKey: key, value: key, table: nil)
        guard !args.isEmpty else { return format }
        return String(format: format, locale: Locale(identifier: code), arguments: args)
    }
}

enum Fmt {
    static var locale: Locale { Locale(identifier: Loc.languageCode) }

    static func bpm(_ v: Double?) -> String {
        guard let v else { return "--" }
        return Int(v.rounded()).formatted(.number.locale(locale))
    }

    static func relative(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.locale = locale
        f.unitsStyle = .full
        return f.localizedString(for: date, relativeTo: .now)
    }

    static func time(_ date: Date) -> String {
        date.formatted(.dateTime.hour().minute().locale(locale))
    }

    static func dayLong(_ date: Date) -> String {
        date.formatted(.dateTime.weekday(.wide).day().month(.wide).locale(locale))
    }

    static func dayShort(_ date: Date) -> String {
        date.formatted(.dateTime.day().month(.abbreviated).locale(locale))
    }

    static func duration(_ seconds: TimeInterval) -> String {
        let minutes = Int(seconds / 60)
        return minutes.formatted(.number.locale(locale))
    }
}

@MainActor @Observable
final class AppSettings {
    var language: String { didSet { UserDefaults.standard.set(language, forKey: SettingsKeys.language) } }
    var appearance: String { didSet { UserDefaults.standard.set(appearance, forKey: SettingsKeys.appearance) } }
    var onboarded: Bool { didSet { UserDefaults.standard.set(onboarded, forKey: SettingsKeys.onboarded) } }

    var highOn: Bool { didSet { UserDefaults.standard.set(highOn, forKey: SettingsKeys.highOn) } }
    var highValue: Int { didSet { UserDefaults.standard.set(highValue, forKey: SettingsKeys.highValue) } }
    var lowOn: Bool { didSet { UserDefaults.standard.set(lowOn, forKey: SettingsKeys.lowOn) } }
    var lowValue: Int { didSet { UserDefaults.standard.set(lowValue, forKey: SettingsKeys.lowValue) } }
    var reminderOn: Bool { didSet { UserDefaults.standard.set(reminderOn, forKey: SettingsKeys.reminderOn) } }
    var reminderHour: Int { didSet { UserDefaults.standard.set(reminderHour, forKey: SettingsKeys.reminderHour) } }
    var reminderMinute: Int { didSet { UserDefaults.standard.set(reminderMinute, forKey: SettingsKeys.reminderMinute) } }
    var summaryOn: Bool { didSet { UserDefaults.standard.set(summaryOn, forKey: SettingsKeys.summaryOn) } }
    var summaryHour: Int { didSet { UserDefaults.standard.set(summaryHour, forKey: SettingsKeys.summaryHour) } }
    var summaryMinute: Int { didSet { UserDefaults.standard.set(summaryMinute, forKey: SettingsKeys.summaryMinute) } }

    init() {
        SettingsKeys.registerDefaults()
        let d = UserDefaults.standard
        language = d.string(forKey: SettingsKeys.language) ?? "system"
        appearance = d.string(forKey: SettingsKeys.appearance) ?? "system"
        onboarded = d.bool(forKey: SettingsKeys.onboarded)
        highOn = d.bool(forKey: SettingsKeys.highOn)
        highValue = d.integer(forKey: SettingsKeys.highValue)
        lowOn = d.bool(forKey: SettingsKeys.lowOn)
        lowValue = d.integer(forKey: SettingsKeys.lowValue)
        reminderOn = d.bool(forKey: SettingsKeys.reminderOn)
        reminderHour = d.integer(forKey: SettingsKeys.reminderHour)
        reminderMinute = d.integer(forKey: SettingsKeys.reminderMinute)
        summaryOn = d.bool(forKey: SettingsKeys.summaryOn)
        summaryHour = d.integer(forKey: SettingsKeys.summaryHour)
        summaryMinute = d.integer(forKey: SettingsKeys.summaryMinute)
    }

    var locale: Locale { Locale(identifier: Loc.languageCode) }
    var layoutDirection: LayoutDirection { Loc.languageCode == "ar" ? .rightToLeft : .leftToRight }
    var colorScheme: ColorScheme? {
        switch appearance {
        case "light": .light
        case "dark": .dark
        default: nil
        }
    }

    /// Changes whenever a notification-relevant setting changes (used to trigger rescheduling).
    var notificationSignature: String {
        "\(highOn)\(highValue)\(lowOn)\(lowValue)\(reminderOn)\(reminderHour):\(reminderMinute)\(summaryOn)\(summaryHour):\(summaryMinute)\(language)"
    }
}
