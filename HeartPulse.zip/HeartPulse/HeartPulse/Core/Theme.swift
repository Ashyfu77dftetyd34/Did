import SwiftUI
import UIKit

extension UIColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(
            red: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255,
            alpha: alpha
        )
    }
}

extension Color {
    /// Adaptive color that resolves differently in Light and Dark Mode.
    init(light: UInt32, dark: UInt32) {
        self.init(uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark ? UIColor(hex: dark) : UIColor(hex: light)
        })
    }
}

/// Modern Classic Luxury palette: midnight, charcoal, white, silver, champagne gold, heart red.
enum Theme {
    static let background = Color(light: 0xF6F4F0, dark: 0x07080B)       // Deep Midnight Black
    static let surface = Color(light: 0xFFFFFF, dark: 0x14161B)           // Elegant Charcoal
    static let surfaceRaised = Color(light: 0xEFEBE4, dark: 0x1E2128)
    static let textPrimary = Color(light: 0x0B0C10, dark: 0xF8F6F1)       // Premium White
    static let textSecondary = Color(light: 0x6B6E76, dark: 0xA8ABB3)     // Soft Silver
    static let gold = Color(light: 0xA88B4A, dark: 0xD4B87A)              // Subtle Champagne Gold
    static let heart = Color(light: 0xD7263D, dark: 0xFF4A5E)             // Heart Red
    static let hairline = Color(light: 0x0B0C10, dark: 0xFFFFFF).opacity(0.08)

    static func number(_ size: CGFloat) -> Font { .system(size: size, weight: .light, design: .serif) }
    static func title(_ size: CGFloat) -> Font { .system(size: size, weight: .semibold, design: .serif) }
}

struct PremiumCard: ViewModifier {
    var padding: CGFloat = 18

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(Theme.surface)
                    .overlay {
                        RoundedRectangle(cornerRadius: 24, style: .continuous)
                            .strokeBorder(
                                LinearGradient(
                                    colors: [Theme.gold.opacity(0.4), Theme.hairline, Theme.hairline],
                                    startPoint: .topLeading, endPoint: .bottomTrailing),
                                lineWidth: 1)
                    }
                    .shadow(color: .black.opacity(0.10), radius: 16, y: 8)
            }
    }
}

extension View {
    func premiumCard(padding: CGFloat = 18) -> some View { modifier(PremiumCard(padding: padding)) }
}

struct GoldButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(Color(hex: 0x1A1408))
            .padding(.vertical, 15)
            .frame(maxWidth: .infinity)
            .background(
                Capsule().fill(LinearGradient(
                    colors: [Color(hex: 0xE9D6A8), Color(hex: 0xC9A765)],
                    startPoint: .top, endPoint: .bottom))
            )
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(duration: 0.25), value: configuration.isPressed)
    }
}

extension Color {
    init(hex: UInt32) {
        self.init(uiColor: UIColor(hex: hex))
    }
}

@MainActor
enum Haptics {
    static func tap() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func select() { UISelectionFeedbackGenerator().selectionChanged() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
}
