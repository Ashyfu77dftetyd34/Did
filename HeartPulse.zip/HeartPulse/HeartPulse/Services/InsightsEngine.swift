import Foundation

struct Insight: Identifiable, Sendable {
    enum Tone: Sendable { case neutral, positive, attention }

    let id: String
    let icon: String
    let titleKey: String
    let bodyKey: String
    let args: [Int]
    let tone: Tone

    var title: String { Loc.t(titleKey) }
    var body: String { Loc.t(bodyKey, args.map { $0 as CVarArg }) }
}

/// Produces informational observations from recorded data. These are NOT diagnoses.
enum InsightsEngine {
    struct Input {
        var todaySamples: [HeartRateSample] = []
        var dailyMonth: [HeartBucket] = []
        var restingDaily: [HeartBucket] = []
        var workouts: [ExerciseSession] = []
        var maxHR: Int?
        var highThreshold = 120
        var lowThreshold = 40
        var now: Date = .now
    }

    static func generate(_ i: Input) -> [Insight] {
        var out: [Insight] = []
        let cal = Calendar.current
        let weekAgo = i.now.addingTimeInterval(-7 * 86_400)
        let twoWeeksAgo = i.now.addingTimeInterval(-14 * 86_400)
        func mean(_ b: [HeartBucket]) -> Double { b.map(\.avg).reduce(0, +) / Double(max(b.count, 1)) }

        // 1. Resting heart rate change
        let restLast = i.restingDaily.filter { $0.date >= weekAgo }
        let restPrev = i.restingDaily.filter { $0.date < weekAgo && $0.date >= twoWeeksAgo }
        if restLast.count >= 3 {
            let now = mean(restLast)
            if restPrev.count >= 3 {
                let delta = Int((now - mean(restPrev)).rounded())
                if abs(delta) >= 3 {
                    out.append(Insight(
                        id: "resting", icon: delta > 0 ? "arrow.up.right" : "arrow.down.right",
                        titleKey: "ins.resting.title",
                        bodyKey: delta > 0 ? "ins.resting.up" : "ins.resting.down",
                        args: [abs(delta), Int(now.rounded())],
                        tone: delta >= 5 ? .attention : (delta < 0 ? .positive : .neutral)))
                } else {
                    out.append(Insight(id: "resting", icon: "equal", titleKey: "ins.resting.title",
                                       bodyKey: "ins.resting.stable", args: [Int(now.rounded())], tone: .neutral))
                }
            } else {
                out.append(Insight(id: "resting", icon: "heart", titleKey: "ins.resting.title",
                                   bodyKey: "ins.resting.stable", args: [Int(now.rounded())], tone: .neutral))
            }
        }

        // 2. Unusual recorded measurements (readings tagged as at rest only)
        let atRest = i.todaySamples.filter { $0.context == .sedentary }
        let high = atRest.filter { $0.bpm > Double(i.highThreshold) }
        let low = atRest.filter { $0.bpm < Double(i.lowThreshold) }
        if !high.isEmpty, let peak = high.map(\.bpm).max() {
            out.append(Insight(id: "unusualHigh", icon: "exclamationmark.circle", titleKey: "ins.unusual.title",
                               bodyKey: "ins.unusual.high", args: [high.count, i.highThreshold, Int(peak.rounded())],
                               tone: .attention))
        }
        if !low.isEmpty, let floor = low.map(\.bpm).min() {
            out.append(Insight(id: "unusualLow", icon: "exclamationmark.circle", titleKey: "ins.unusual.title",
                               bodyKey: "ins.unusual.low", args: [low.count, i.lowThreshold, Int(floor.rounded())],
                               tone: .attention))
        }
        if high.isEmpty, low.isEmpty, !i.todaySamples.isEmpty {
            out.append(Insight(id: "unusualNone", icon: "checkmark.circle", titleKey: "ins.unusual.title",
                               bodyKey: "ins.unusual.none", args: [i.lowThreshold, i.highThreshold], tone: .positive))
        }

        // 3. Daily trend vs the last month
        let startToday = cal.startOfDay(for: i.now)
        let earlier = i.dailyMonth.filter { $0.date < startToday }
        if !i.todaySamples.isEmpty, earlier.count >= 5 {
            let todayAvg = i.todaySamples.map(\.bpm).reduce(0, +) / Double(i.todaySamples.count)
            let delta = Int((todayAvg - mean(earlier)).rounded())
            let key = delta >= 5 ? "ins.daily.higher" : (delta <= -5 ? "ins.daily.lower" : "ins.daily.similar")
            out.append(Insight(id: "daily", icon: "sun.max", titleKey: "ins.daily.title", bodyKey: key,
                               args: [abs(delta), Int(todayAvg.rounded())], tone: .neutral))
        }

        // 4. Weekly trend
        let wLast = i.dailyMonth.filter { $0.date >= weekAgo }
        let wPrev = i.dailyMonth.filter { $0.date < weekAgo && $0.date >= twoWeeksAgo }
        if wLast.count >= 3, wPrev.count >= 3 {
            let delta = Int((mean(wLast) - mean(wPrev)).rounded())
            let key = delta >= 3 ? "ins.weekly.up" : (delta <= -3 ? "ins.weekly.down" : "ins.weekly.stable")
            out.append(Insight(id: "weekly", icon: "calendar", titleKey: "ins.weekly.title", bodyKey: key,
                               args: [abs(delta), Int(mean(wLast).rounded())], tone: .neutral))
        }

        // 5. Exercise patterns
        if !i.workouts.isEmpty {
            let avg = Int((i.workouts.map(\.avg).reduce(0, +) / Double(i.workouts.count)).rounded())
            let peak = Int((i.workouts.map(\.max).max() ?? 0).rounded())
            if let maxHR = i.maxHR, maxHR > 0 {
                let pct = Int((Double(peak) / Double(maxHR) * 100).rounded())
                out.append(Insight(id: "exercise", icon: "figure.run", titleKey: "ins.exercise.title",
                                   bodyKey: "ins.exercise.withmax", args: [i.workouts.count, avg, peak, pct], tone: .neutral))
            } else {
                out.append(Insight(id: "exercise", icon: "figure.run", titleKey: "ins.exercise.title",
                                   bodyKey: "ins.exercise.plain", args: [i.workouts.count, avg, peak], tone: .neutral))
            }
        }

        return out.sorted { ($0.tone == .attention ? 0 : 1) < ($1.tone == .attention ? 0 : 1) }
    }
}
