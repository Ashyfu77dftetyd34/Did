import Foundation
import HealthKit

struct UncheckedBox<T>: @unchecked Sendable {
    let value: T
}

/// Thin wrapper around HealthKit. It only ever returns what Apple Health contains.
/// It never fabricates readings.
final class HealthKitService: @unchecked Sendable {
    static let shared = HealthKitService()

    enum Kind { case heartRate, resting }

    private let store = HKHealthStore()
    private let hrType = HKQuantityType(.heartRate)
    private let restingType = HKQuantityType(.restingHeartRate)
    private var observer: HKObserverQuery?

    var isAvailable: Bool { HKHealthStore.isHealthDataAvailable() }

    private var readTypes: Set<HKObjectType> {
        [hrType, restingType, HKObjectType.workoutType()]
    }

    private func type(_ kind: Kind) -> HKQuantityType {
        kind == .heartRate ? hrType : restingType
    }

    private static var bpmUnit: HKUnit { HKUnit.count().unitDivided(by: .minute()) }

    // MARK: Authorization

    /// True when the system permission sheet has not yet been shown for the requested types.
    func needsAuthorizationPrompt() async -> Bool {
        guard isAvailable else { return false }
        let status = try? await store.statusForAuthorizationRequest(toShare: [], read: readTypes)
        return status != .unnecessary
    }

    func requestAuthorization() async throws {
        try await store.requestAuthorization(toShare: [], read: readTypes)
    }

    // MARK: Samples

    func samples(from start: Date, to end: Date, limit: Int?) async throws -> [HeartRateSample] {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let descriptor = HKSampleQueryDescriptor(
            predicates: [.quantitySample(type: hrType, predicate: predicate)],
            sortDescriptors: [SortDescriptor(\.endDate, order: .reverse)],
            limit: limit)
        return try await descriptor.result(for: store).map(Self.convert)
    }

    func latest(_ kind: Kind) async throws -> HeartRateSample? {
        let descriptor = HKSampleQueryDescriptor(
            predicates: [.quantitySample(type: type(kind))],
            sortDescriptors: [SortDescriptor(\.endDate, order: .reverse)],
            limit: 1)
        return try await descriptor.result(for: store).map(Self.convert).first
    }

    // MARK: Statistics

    func overall(_ kind: Kind, from start: Date, to end: Date) async throws -> HeartStats? {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let descriptor = HKStatisticsQueryDescriptor(
            predicate: .quantitySample(type: type(kind), predicate: predicate),
            options: [.discreteAverage, .discreteMin, .discreteMax])
        guard let stats = try await descriptor.result(for: store),
              let avg = stats.averageQuantity()?.doubleValue(for: Self.bpmUnit),
              let min = stats.minimumQuantity()?.doubleValue(for: Self.bpmUnit),
              let max = stats.maximumQuantity()?.doubleValue(for: Self.bpmUnit)
        else { return nil }
        return HeartStats(avg: avg, min: min, max: max)
    }

    func buckets(_ kind: Kind, from start: Date, to end: Date, interval: DateComponents) async throws -> [HeartBucket] {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let descriptor = HKStatisticsCollectionQueryDescriptor(
            predicate: .quantitySample(type: type(kind), predicate: predicate),
            options: [.discreteAverage, .discreteMin, .discreteMax],
            anchorDate: start,
            intervalComponents: interval)
        let collection = try await descriptor.result(for: store)
        var out: [HeartBucket] = []
        let unit = Self.bpmUnit
        collection.enumerateStatistics(from: start, to: end) { stats, _ in
            guard let avg = stats.averageQuantity()?.doubleValue(for: unit),
                  let mn = stats.minimumQuantity()?.doubleValue(for: unit),
                  let mx = stats.maximumQuantity()?.doubleValue(for: unit)
            else { return }
            out.append(HeartBucket(date: stats.startDate, avg: avg, min: mn, max: mx))
        }
        return out
    }

    func buckets(_ kind: Kind, range: TimeRange) async throws -> [HeartBucket] {
        let r = kind == .resting ? range.restingRange : range
        return try await buckets(kind, from: r.start(), to: r.end(), interval: r.interval)
    }

    // MARK: Workouts

    func workouts(since start: Date) async throws -> [ExerciseSession] {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: nil)
        let descriptor = HKSampleQueryDescriptor(
            predicates: [.workout(predicate)],
            sortDescriptors: [SortDescriptor(\.endDate, order: .reverse)],
            limit: 80)
        let workouts = try await descriptor.result(for: store)
        let unit = Self.bpmUnit
        return workouts.compactMap { w in
            guard let stats = w.statistics(for: HKQuantityType(.heartRate)),
                  let avg = stats.averageQuantity()?.doubleValue(for: unit),
                  let mx = stats.maximumQuantity()?.doubleValue(for: unit)
            else { return nil }
            return ExerciseSession(
                id: w.uuid, nameKey: Self.nameKey(w.workoutActivityType),
                date: w.startDate, duration: w.duration, avg: avg, max: mx)
        }
    }

    // MARK: Live updates & background delivery

    /// Yields samples as Apple Health receives them (e.g. when Apple Watch syncs).
    /// The first element may contain today's existing samples; consumers must de-duplicate by id.
    func updates() -> AsyncStream<[HeartRateSample]> {
        AsyncStream { continuation in
            let task = Task {
                let start = Calendar.current.startOfDay(for: .now)
                let predicate = HKQuery.predicateForSamples(withStart: start, end: nil)
                let descriptor = HKAnchoredObjectQueryDescriptor(
                    predicates: [.quantitySample(type: hrType, predicate: predicate)],
                    anchor: nil)
                do {
                    for try await result in descriptor.results(for: store) {
                        let converted = result.addedSamples.map(Self.convert)
                        if !converted.isEmpty { continuation.yield(converted) }
                    }
                } catch {}
                continuation.finish()
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    func enableBackgroundDelivery() async {
        guard isAvailable else { return }
        try? await store.enableBackgroundDelivery(for: hrType, frequency: .immediate)
    }

    /// Registers an observer so iOS can wake the app when new heart rate data arrives.
    /// iOS decides when to deliver; delivery is never guaranteed to be instant.
    func startObserver(_ handler: @escaping @Sendable () async -> Void) {
        guard isAvailable, observer == nil else { return }
        let query = HKObserverQuery(sampleType: hrType, predicate: nil) { _, completion, error in
            let done = UncheckedBox(completion)
            Task {
                if error == nil { await handler() }
                done.value()
            }
        }
        store.execute(query)
        observer = query
    }

    // MARK: Conversion

    private static func convert(_ s: HKQuantitySample) -> HeartRateSample {
        let raw = (s.metadata?[HKMetadataKeyHeartRateMotionContext] as? NSNumber)?.intValue ?? 0
        return HeartRateSample(
            id: s.uuid,
            bpm: s.quantity.doubleValue(for: bpmUnit),
            date: s.endDate,
            source: s.device?.name ?? s.sourceRevision.source.name,
            context: MotionContext(rawValue: raw) ?? .notSet)
    }

    private static func nameKey(_ t: HKWorkoutActivityType) -> String {
        switch t {
        case .running: return "workout.running"
        case .walking: return "workout.walking"
        case .cycling: return "workout.cycling"
        case .swimming: return "workout.swimming"
        case .hiking: return "workout.hiking"
        case .yoga: return "workout.yoga"
        case .traditionalStrengthTraining, .functionalStrengthTraining: return "workout.strength"
        case .highIntensityIntervalTraining: return "workout.hiit"
        case .elliptical: return "workout.elliptical"
        case .rowing: return "workout.rowing"
        default: return "workout.other"
        }
    }
}
