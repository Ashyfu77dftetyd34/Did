import UIKit

struct ReportData {
    var name: String
    var age: Int?
    var range: TimeRange
    var stats: HeartStats?
    var restingAvg: Double?
    var buckets: [HeartBucket]
    var insights: [Insight]
    var generated: Date = .now
}

/// Renders a one-page A4 PDF report. Arabic is laid out right-to-left.
enum PDFReportExporter {
    private static let pageW: CGFloat = 595
    private static let pageH: CGFloat = 842
    private static let margin: CGFloat = 40

    @MainActor
    static func make(_ data: ReportData) throws -> URL {
        let rtl = Loc.languageCode == "ar"
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageW, height: pageH))
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("HeartPulse-Report-\(Int(data.generated.timeIntervalSince1970)).pdf")

        let gold = UIColor(hex: 0xB89B5E)
        let red = UIColor(hex: 0xD7263D)
        let ink = UIColor(hex: 0x15161A)
        let grey = UIColor(hex: 0x6B6E76)

        func draw(_ text: String, font: UIFont, color: UIColor, x: CGFloat, y: CGFloat, w: CGFloat) -> CGFloat {
            let style = NSMutableParagraphStyle()
            style.alignment = rtl ? .right : .left
            style.baseWritingDirection = rtl ? .rightToLeft : .leftToRight
            let attr = NSAttributedString(string: text, attributes: [
                .font: font, .foregroundColor: color, .paragraphStyle: style])
            let box = CGSize(width: w, height: .greatestFiniteMagnitude)
            let h = ceil(attr.boundingRect(with: box, options: .usesLineFragmentOrigin, context: nil).height)
            attr.draw(in: CGRect(x: x, y: y, width: w, height: h))
            return h
        }

        try renderer.writePDF(to: url) { ctx in
            ctx.beginPage()
            let g = ctx.cgContext
            let contentW = pageW - margin * 2

            // Header band
            g.setFillColor(UIColor(hex: 0x07080B).cgColor)
            g.fill(CGRect(x: 0, y: 0, width: pageW, height: 96))
            g.setFillColor(gold.cgColor)
            g.fill(CGRect(x: 0, y: 96, width: pageW, height: 2))
            _ = draw(Loc.t("pdf.title"), font: .systemFont(ofSize: 24, weight: .semibold),
                     color: UIColor(hex: 0xF8F6F1), x: margin, y: 28, w: contentW)
            _ = draw(Loc.t("pdf.subtitle"), font: .systemFont(ofSize: 11), color: gold,
                     x: margin, y: 62, w: contentW)

            // Meta
            var y: CGFloat = 116
            var meta = "\(Loc.t(data.range.titleKey)) · \(Fmt.dayShort(data.range.start())) – \(Fmt.dayShort(.now))"
            if !data.name.isEmpty { meta = "\(data.name) · " + meta }
            if let age = data.age { meta += " · \(Loc.t("pdf.age", [age]))" }
            y += draw(meta, font: .systemFont(ofSize: 12), color: ink, x: margin, y: y, w: contentW) + 4
            y += draw(Loc.t("pdf.generated", [Fmt.dayLong(data.generated)]), font: .systemFont(ofSize: 10),
                      color: grey, x: margin, y: y, w: contentW) + 18

            // Stat tiles
            let tiles: [(String, String)] = [
                (Loc.t("common.average"), Fmt.bpm(data.stats?.avg)),
                (Loc.t("common.minimum"), Fmt.bpm(data.stats?.min)),
                (Loc.t("common.maximum"), Fmt.bpm(data.stats?.max)),
                (Loc.t("common.resting"), Fmt.bpm(data.restingAvg))
            ]
            let tileW = (contentW - 3 * 10) / 4
            for (idx, tile) in tiles.enumerated() {
                let col = rtl ? 3 - idx : idx
                let x = margin + CGFloat(col) * (tileW + 10)
                let rect = CGRect(x: x, y: y, width: tileW, height: 62)
                g.setFillColor(UIColor(hex: 0xF4F1EA).cgColor)
                UIBezierPath(roundedRect: rect, cornerRadius: 10).fill()
                _ = draw(tile.0, font: .systemFont(ofSize: 9), color: grey, x: x + 8, y: y + 8, w: tileW - 16)
                _ = draw(tile.1, font: .systemFont(ofSize: 24, weight: .light), color: ink, x: x + 8, y: y + 24, w: tileW - 16)
                _ = draw(Loc.t("common.bpm"), font: .systemFont(ofSize: 8), color: gold, x: x + 8, y: y + 50, w: tileW - 16)
            }
            y += 82

            // Chart
            _ = draw(Loc.t("pdf.chart"), font: .systemFont(ofSize: 13, weight: .semibold), color: ink, x: margin, y: y, w: contentW)
            y += 22
            let chartRect = CGRect(x: margin, y: y, width: contentW, height: 190)
            g.setFillColor(UIColor(hex: 0xFAF8F4).cgColor)
            UIBezierPath(roundedRect: chartRect, cornerRadius: 10).fill()
            drawChart(g, data.buckets, in: chartRect.insetBy(dx: 14, dy: 14), rtl: rtl, red: red, grey: grey)
            y += 190 + 20

            // Insights
            _ = draw(Loc.t("pdf.insights"), font: .systemFont(ofSize: 13, weight: .semibold), color: ink, x: margin, y: y, w: contentW)
            y += 22
            if data.insights.isEmpty {
                y += draw(Loc.t("pdf.noInsights"), font: .systemFont(ofSize: 10), color: grey, x: margin, y: y, w: contentW)
            }
            for insight in data.insights.prefix(5) {
                guard y < pageH - 110 else { break }
                y += draw(insight.title, font: .systemFont(ofSize: 11, weight: .semibold), color: ink, x: margin, y: y, w: contentW) + 2
                y += draw(insight.body, font: .systemFont(ofSize: 10), color: grey, x: margin, y: y, w: contentW) + 8
            }

            // Disclaimer
            g.setFillColor(gold.cgColor)
            g.fill(CGRect(x: margin, y: pageH - 78, width: contentW, height: 1))
            _ = draw(Loc.t("pdf.disclaimer"), font: .systemFont(ofSize: 8.5), color: grey, x: margin, y: pageH - 70, w: contentW)
        }
        return url
    }

    private static func drawChart(_ g: CGContext, _ buckets: [HeartBucket], in rect: CGRect,
                                  rtl: Bool, red: UIColor, grey: UIColor) {
        guard buckets.count >= 2,
              let lo = buckets.map(\.min).min(), let hi = buckets.map(\.max).max(),
              let t0 = buckets.first?.date, let t1 = buckets.last?.date, t1 > t0 else {
            let style = NSMutableParagraphStyle(); style.alignment = .center
            NSAttributedString(string: Loc.t("common.noData"), attributes: [
                .font: UIFont.systemFont(ofSize: 11), .foregroundColor: grey, .paragraphStyle: style
            ]).draw(in: CGRect(x: rect.minX, y: rect.midY - 8, width: rect.width, height: 20))
            return
        }
        let span = max(hi - lo, 1)
        func point(_ date: Date, _ v: Double) -> CGPoint {
            var fx = CGFloat(date.timeIntervalSince(t0) / t1.timeIntervalSince(t0))
            if rtl { fx = 1 - fx }
            return CGPoint(x: rect.minX + fx * rect.width,
                           y: rect.maxY - CGFloat((v - lo) / span) * rect.height)
        }
        // Min–max band
        g.setFillColor(red.withAlphaComponent(0.12).cgColor)
        let band = UIBezierPath()
        band.move(to: point(buckets[0].date, buckets[0].max))
        for b in buckets.dropFirst() { band.addLine(to: point(b.date, b.max)) }
        for b in buckets.reversed() { band.addLine(to: point(b.date, b.min)) }
        band.close()
        band.fill()
        // Average line
        g.setStrokeColor(red.cgColor)
        g.setLineWidth(1.8)
        let line = UIBezierPath()
        line.move(to: point(buckets[0].date, buckets[0].avg))
        for b in buckets.dropFirst() { line.addLine(to: point(b.date, b.avg)) }
        line.stroke()
        // Axis labels
        for (v, py) in [(hi, rect.minY), (lo, rect.maxY)] {
            NSAttributedString(string: Fmt.bpm(v), attributes: [
                .font: UIFont.systemFont(ofSize: 8), .foregroundColor: grey
            ]).draw(at: CGPoint(x: rtl ? rect.maxX - 18 : rect.minX, y: py - 10))
        }
    }
}
