import Foundation
import UserNotifications

enum NotificationService {
    private static let reminderID = "heartpulse.reminder"
    private static let summaryID = "heartpulse.summary"

    static func requestAuthorization() async -> Bool {
        (try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound, .badge])) ?? false
    }

    static func status() async -> UNAuthorizationStatus {
        await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
    }

    /// Rebuilds the repeating reminder and daily summary notifications from saved settings.
    static func reschedule() async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [reminderID, summaryID])
        let d = UserDefaults.standard

        if d.bool(forKey: SettingsKeys.reminderOn) {
            await schedule(
                id: reminderID, titleKey: "notif.reminder.title", bodyKey: "notif.reminder.body",
                hour: d.integer(forKey: SettingsKeys.reminderHour),
                minute: d.integer(forKey: SettingsKeys.reminderMinute))
        }
        if d.bool(forKey: SettingsKeys.summaryOn) {
            // The text is static: iOS cannot run our code at a fixed time to compute fresh numbers.
            await schedule(
                id: summaryID, titleKey: "notif.summary.title", bodyKey: "notif.summary.body",
                hour: d.integer(forKey: SettingsKeys.summaryHour),
                minute: d.integer(forKey: SettingsKeys.summaryMinute))
        }
    }

    private static func schedule(id: String, titleKey: String, bodyKey: String, hour: Int, minute: Int) async {
        let content = UNMutableNotificationContent()
        content.title = Loc.t(titleKey)
        content.body = Loc.t(bodyKey)
        content.sound = .default
        let trigger = UNCalendarNotificationTrigger(
            dateMatching: DateComponents(hour: hour, minute: minute), repeats: true)
        try? await UNUserNotificationCenter.current()
            .add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
    }

    static func sendAlert(title: String, body: String) async {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        content.interruptionLevel = .timeSensitive
        try? await UNUserNotificationCenter.current().add(
            UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil))
    }
}

/// Evaluates newly recorded readings against the user's thresholds.
/// Runs when HealthKit wakes the app (background delivery) or while the app is open.
/// iOS may delay or coalesce deliveries, and readings only exist once Apple Watch syncs them.
enum AlertMonitor {
    static func start() {
        let d = UserDefaults.standard
        guard d.bool(forKey: SettingsKeys.onboarded), HealthKitService.shared.isAvailable else { return }
        HealthKitService.shared.startObserver { await check() }
        Task { await HealthKitService.shared.enableBackgroundDelivery() }
    }

    static func check() async {
        let d = UserDefaults.standard
        let highOn = d.bool(forKey: SettingsKeys.highOn)
        let lowOn = d.bool(forKey: SettingsKeys.lowOn)
        guard highOn || lowOn else { return }

        let now = Date()
        let since = (d.object(forKey: SettingsKeys.lastAlertCheck) as? Date) ?? now.addingTimeInterval(-900)
        d.set(now, forKey: SettingsKeys.lastAlertCheck)

        guard let samples = try? await HealthKitService.shared.samples(from: since, to: now, limit: 500) else { return }
        // Only readings Apple Watch tags as "at rest" are considered, so workouts don't trigger alerts.
        let atRest = samples.filter { $0.context == .sedentary }

        // At most one alert every 30 minutes.
        if let last = d.object(forKey: SettingsKeys.lastAlertDate) as? Date, now.timeIntervalSince(last) < 1800 { return }

        let high = d.integer(forKey: SettingsKeys.highValue)
        let low = d.integer(forKey: SettingsKeys.lowValue)

        if highOn, let worst = atRest.max(by: { $0.bpm < $1.bpm }), worst.bpm > Double(high) {
            d.set(now, forKey: SettingsKeys.lastAlertDate)
            await NotificationService.sendAlert(
                title: Loc.t("notif.high.title"),
                body: Loc.t("notif.high.body", [Int(worst.bpm.rounded()), high]))
        } else if lowOn, let worst = atRest.min(by: { $0.bpm < $1.bpm }), worst.bpm < Double(low) {
            d.set(now, forKey: SettingsKeys.lastAlertDate)
            await NotificationService.sendAlert(
                title: Loc.t("notif.low.title"),
                body: Loc.t("notif.low.body", [Int(worst.bpm.rounded()), low]))
        }
    }
}
