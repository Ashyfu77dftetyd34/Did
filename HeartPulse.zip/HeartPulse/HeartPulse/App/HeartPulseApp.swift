import SwiftUI
import SwiftData

@main
struct HeartPulseApp: App {
    @State private var settings = AppSettings()
    @State private var store = HealthDataStore()
    private let container: ModelContainer

    init() {
        SettingsKeys.registerDefaults()
        do {
            container = try ModelContainer(for: UserProfile.self, FavoriteReading.self)
        } catch {
            fatalError("Could not create local database: \(error)")
        }
        // Must be registered at launch so HealthKit can wake the app for background delivery.
        AlertMonitor.start()
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if settings.onboarded {
                    RootView()
                } else {
                    OnboardingView()
                }
            }
            .environment(settings)
            .environment(store)
            .environment(\.locale, settings.locale)
            .environment(\.layoutDirection, settings.layoutDirection)
            .preferredColorScheme(settings.colorScheme)
            .tint(Theme.gold)
            .id(settings.language)
        }
        .modelContainer(container)
    }
}
