import Foundation

enum MotionContext: Int, Sendable, Hashable {
    case notSet = 0, sedentary = 1, active = 2
}

/// A single heart rate reading exactly as recorded in Apple Health. Never synthesized.
struct HeartRateSample: Identifiable, Hashable, Sendable {
    let id: UUID
    let bpm: Double
    let date: Date
    let source: String
    let context: MotionContext
}

/// Aggregated statistics for a time bucket (hour, day, week or month).
struct HeartBucket: Identifiable, Hashable, Sendable {
    var id: Date { date }
    let date: Date
    let avg: Double
    let min: Double
    let max: Double
}

struct HeartStats: Hashable, Sendable {
    let avg: Double
    let min: Double
    let max: Double
}

struct ExerciseSession: Identifiable, Hashable, Sendable {
    let id: UUID
    let nameKey: String
    let date: Date
    let duration: TimeInterval
    let avg: Double
    let max: Double
}

enum Freshness: Sendable {
    /// Received within the last 2 minutes (typical while a workout is running on Apple Watch).
    case live
    /// Received within the last 30 minutes.
    case recent
    /// Older recorded measurement.
    case recorded

    static func of(_ sample: HeartRateSample, now: Date = .now) -> Freshness {
        let age = now.timeIntervalSince(sample.date)
        if age <= 120 { return .live }
        if age <= 1800 { return .recent }
        return .recorded
    }
}

enum AppTab: String, CaseIterable, Identifiable {
    case home, heartRate, analytics, history, profile
    var id: String { rawValue }

    var titleKey: String { "tab.\(rawValue)" }
    var icon: String {
        switch self {
        case .home: "house"
        case .heartRate: "heart.text.square"
        case .analytics: "chart.xyaxis.line"
        case .history: "clock.arrow.circlepath"
        case .profile: "person"
        }
    }
}

enum TimeRange: String, CaseIterable, Identifiable, Sendable {
    case day, week, month, sixMonths, year
    var id: String { rawValue }
    var titleKey: String { "range.\(rawValue)" }

    func start(now: Date = .now, calendar: Calendar = .current) -> Date {
        func daysAgo(_ n: Int) -> Date {
            calendar.startOfDay(for: calendar.date(byAdding: .day, value: -n, to: now) ?? now)
        }
        switch self {
        case .day: return calendar.startOfDay(for: now)
        case .week: return daysAgo(6)
        case .month: return daysAgo(29)
        case .sixMonths: return daysAgo(181)
        case .year:
            let back = calendar.date(byAdding: .month, value: -11, to: now) ?? now
            return calendar.date(from: calendar.dateComponents([.year, .month], from: back)) ?? back
        }
    }

    func end(now: Date = .now, calendar: Calendar = .current) -> Date {
        self == .day ? start(now: now, calendar: calendar).addingTimeInterval(86_400) : now
    }

    var interval: DateComponents {
        switch self {
        case .day: DateComponents(hour: 1)
        case .week, .month: DateComponents(day: 1)
        case .sixMonths: DateComponents(day: 7)
        case .year: DateComponents(month: 1)
        }
    }

    /// Resting heart rate is a daily value, so the "day" range falls back to a week.
    var restingRange: TimeRange { self == .day ? .week : self }

    var axisFormat: Date.FormatStyle {
        switch self {
        case .day: .dateTime.hour()
        case .week: .dateTime.weekday(.abbreviated)
        case .month, .sixMonths: .dateTime.day().month(.abbreviated)
        case .year: .dateTime.month(.abbreviated)
        }
    }
}

enum HeartZone: Int, CaseIterable {
    case recovery = 1, light, moderate, hard, peak

    var titleKey: String { "zone.\(rawValue)" }

    static func zone(bpm: Double, maxHR: Double) -> HeartZone {
        let pct = bpm / maxHR
        switch pct {
        case ..<0.6: return .recovery
        case ..<0.7: return .light
        case ..<0.8: return .moderate
        case ..<0.9: return .hard
        default: return .peak
        }
    }
}
