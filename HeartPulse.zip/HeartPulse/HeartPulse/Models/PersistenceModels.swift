import Foundation
import SwiftData

@Model
final class UserProfile {
    var name: String
    var birthYear: Int?
    var createdAt: Date

    init(name: String = "", birthYear: Int? = nil) {
        self.name = name
        self.birthYear = birthYear
        self.createdAt = .now
    }

    var age: Int? {
        guard let birthYear else { return nil }
        let a = Calendar.current.component(.year, from: .now) - birthYear
        return (0...120).contains(a) ? a : nil
    }

    /// Informational estimate (220 − age). Not a medical measurement.
    var estimatedMaxHR: Double? { age.map { Double(220 - $0) } }
}

@Model
final class FavoriteReading {
    @Attribute(.unique) var sampleID: UUID
    var bpm: Double
    var date: Date
    var source: String
    var contextRaw: Int
    var note: String

    init(sample: HeartRateSample, note: String = "") {
        self.sampleID = sample.id
        self.bpm = sample.bpm
        self.date = sample.date
        self.source = sample.source
        self.contextRaw = sample.context.rawValue
        self.note = note
    }

    var context: MotionContext { MotionContext(rawValue: contextRaw) ?? .notSet }
}
