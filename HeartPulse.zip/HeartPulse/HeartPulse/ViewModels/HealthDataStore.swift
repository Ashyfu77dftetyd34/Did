import Foundation
import Observation

/// Single source of truth for Home / Heart Rate screens (MVVM view-model).
@MainActor @Observable
final class HealthDataStore {
    enum Access { case loading, unavailable, needsPermission, ready }

    private(set) var access: Access = .loading
    private(set) var latest: HeartRateSample?
    private(set) var today: [HeartRateSample] = []
    private(set) var resting: HeartRateSample?
    private(set) var insights: [Insight] = []
    private(set) var sources: [String] = []
    private(set) var isRefreshing = false

    private let service = HealthKitService.shared
    private var liveTask: Task<Void, Never>?

    // MARK: Derived

    var freshness: Freshness? { latest.map { Freshness.of($0) } }

    var todayStats: HeartStats? {
        guard !today.isEmpty else { return nil }
        let values = today.map(\.bpm)
        return HeartStats(avg: values.reduce(0, +) / Double(values.count),
                          min: values.min() ?? 0, max: values.max() ?? 0)
    }

    var todayHourly: [HeartBucket] {
        let cal = Calendar.current
        let groups = Dictionary(grouping: today) { cal.dateInterval(of: .hour, for: $0.date)?.start ?? $0.date }
        return groups.map { date, items in
            let v = items.map(\.bpm)
            return HeartBucket(date: date, avg: v.reduce(0, +) / Double(v.count),
                               min: v.min() ?? 0, max: v.max() ?? 0)
        }.sorted { $0.date < $1.date }
    }

    // MARK: Lifecycle

    func bootstrap(age: Int?) async {
        guard service.isAvailable else { access = .unavailable; return }
        if await service.needsAuthorizationPrompt() {
            access = .needsPermission
            return
        }
        access = .ready
        await refresh(age: age)
        startLive()
    }

    func requestAccess(age: Int?) async {
        guard service.isAvailable else { access = .unavailable; return }
        try? await service.requestAuthorization()
        access = .ready
        await refresh(age: age)
        startLive()
    }

    func refresh(age: Int?) async {
        guard access == .ready else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        let cal = Calendar.current
        let now = Date()
        let startToday = cal.startOfDay(for: now)
        let d = UserDefaults.standard

        latest = (try? await service.latest(.heartRate)) ?? nil
        resting = (try? await service.latest(.resting)) ?? nil
        today = ((try? await service.samples(from: startToday, to: now.addingTimeInterval(60), limit: nil)) ?? [])
            .sorted { $0.date < $1.date }

        let weekSamples = (try? await service.samples(from: now.addingTimeInterval(-7 * 86_400), to: now, limit: 400)) ?? []
        sources = Array(Set(weekSamples.map(\.source) + (latest.map { [$0.source] } ?? []))).sorted()

        let month = (try? await service.buckets(.heartRate, range: .month)) ?? []
        let restingDaily = (try? await service.buckets(
            .resting, from: cal.startOfDay(for: now.addingTimeInterval(-14 * 86_400)), to: now,
            interval: DateComponents(day: 1))) ?? []
        let workouts = (try? await service.workouts(since: now.addingTimeInterval(-30 * 86_400))) ?? []

        insights = InsightsEngine.generate(.init(
            todaySamples: today, dailyMonth: month, restingDaily: restingDaily, workouts: workouts,
            maxHR: age.map { 220 - $0 },
            highThreshold: d.integer(forKey: SettingsKeys.highValue),
            lowThreshold: d.integer(forKey: SettingsKeys.lowValue)))
    }

    func startLive() {
        guard access == .ready, liveTask == nil else { return }
        liveTask = Task { [weak self] in
            guard let stream = self?.service.updates() else { return }
            for await batch in stream {
                self?.merge(batch)
            }
        }
    }

    func stopLive() {
        liveTask?.cancel()
        liveTask = nil
    }

    private func merge(_ batch: [HeartRateSample]) {
        let existing = Set(today.map(\.id))
        let fresh = batch.filter { !existing.contains($0.id) }
        guard !fresh.isEmpty else { return }
        today = (today + fresh).sorted { $0.date < $1.date }
        if let newest = fresh.max(by: { $0.date < $1.date }), newest.date >= (latest?.date ?? .distantPast) {
            latest = newest
        }
    }
}
