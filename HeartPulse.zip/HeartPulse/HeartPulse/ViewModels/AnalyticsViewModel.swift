import Foundation
import Observation

@MainActor @Observable
final class AnalyticsViewModel {
    private(set) var buckets: [HeartBucket] = []
    private(set) var resting: [HeartBucket] = []
    private(set) var workouts: [ExerciseSession] = []
    private(set) var stats: HeartStats?
    private(set) var restingStats: HeartStats?
    private(set) var isLoading = false

    private let service = HealthKitService.shared

    func load(range: TimeRange) async {
        isLoading = true
        defer { isLoading = false }

        let start = range.start()
        let end = range.end()
        let rRange = range.restingRange

        let b = (try? await service.buckets(.heartRate, range: range)) ?? []
        let s = (try? await service.overall(.heartRate, from: start, to: Date())) ?? nil
        let r = (try? await service.buckets(.resting, range: range)) ?? []
        let rs = (try? await service.overall(.resting, from: rRange.start(), to: Date())) ?? nil
        let w = (try? await service.workouts(since: rRange.start())) ?? []
        _ = end

        guard !Task.isCancelled else { return }
        buckets = b
        stats = s
        resting = r
        restingStats = rs
        workouts = w.sorted { $0.date < $1.date }
    }
}
