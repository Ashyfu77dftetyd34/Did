import SwiftUI
import SwiftData

struct ProfileView: View {
    @Environment(AppSettings.self) private var settings
    @Environment(\.modelContext) private var context
    @Query private var profiles: [UserProfile]
    @State private var showExport = false

    var body: some View {
        NavigationStack {
            List {
                if let profile = profiles.first {
                    ProfileEditor(profile: profile)
                }

                Section("prof.preferences") {
                    Picker("prof.language", selection: Bindable(settings).language) {
                        Text("prof.system").tag("system")
                        Text(verbatim: "English").tag("en")
                        Text(verbatim: "العربية").tag("ar")
                    }
                    Picker("prof.appearance", selection: Bindable(settings).appearance) {
                        Text("prof.system").tag("system")
                        Text("prof.light").tag("light")
                        Text("prof.dark").tag("dark")
                    }
                }

                Section("prof.manage") {
                    NavigationLink { NotificationSettingsView() } label: { Label("prof.notifications", systemImage: "bell") }
                    NavigationLink { PrivacyView() } label: { Label("prof.privacy", systemImage: "lock.shield") }
                    Button { showExport = true } label: { Label("prof.export", systemImage: "doc.richtext") }
                }

                Section("prof.about") {
                    Text("common.disclaimer").font(.footnote).foregroundStyle(Theme.textSecondary)
                    LabeledContent("prof.version", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0")
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.background)
            .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 96) }
            .navigationTitle(Text("tab.profile"))
            .sheet(isPresented: $showExport) { ExportReportView() }
        }
    }
}

struct ProfileEditor: View {
    @Bindable var profile: UserProfile
    private let years = Array((1920...Calendar.current.component(.year, from: .now)).reversed())

    var body: some View {
        Section("prof.you") {
            TextField("prof.name", text: $profile.name)
            Picker("prof.birthYear", selection: $profile.birthYear) {
                Text(verbatim: "—").tag(Int?.none)
                ForEach(years, id: \.self) { y in Text(verbatim: String(y)).tag(Int?.some(y)) }
            }
            if let age = profile.age {
                LabeledContent("prof.age", value: age.formatted(.number.locale(Fmt.locale)))
                if let max = profile.estimatedMaxHR {
                    LabeledContent("prof.maxHR", value: Fmt.bpm(max))
                }
                Text("prof.maxHRNote").font(.caption).foregroundStyle(Theme.textSecondary)
            }
        }
    }
}

struct NotificationSettingsView: View {
    @Environment(AppSettings.self) private var settings
    @Environment(\.openURL) private var openURL
    @State private var denied = false

    var body: some View {
        @Bindable var s = settings
        List {
            Section {
                Text("notif.explain").font(.footnote).foregroundStyle(Theme.textSecondary)
            }
            if denied {
                Section {
                    Text("notif.denied").font(.footnote)
                    Button("common.openSettings") {
                        if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
                    }
                }
            }
            Section("notif.alerts") {
                Toggle("notif.highToggle", isOn: $s.highOn)
                if s.highOn {
                    Stepper(value: $s.highValue, in: 90...200, step: 5) {
                        Text(Loc.t("notif.above", [s.highValue]))
                    }
                }
                Toggle("notif.lowToggle", isOn: $s.lowOn)
                if s.lowOn {
                    Stepper(value: $s.lowValue, in: 30...70, step: 5) {
                        Text(Loc.t("notif.below", [s.lowValue]))
                    }
                }
                Text("notif.restOnly").font(.caption).foregroundStyle(Theme.textSecondary)
            }
            Section("notif.scheduled") {
                Toggle("notif.reminderToggle", isOn: $s.reminderOn)
                if s.reminderOn {
                    DatePicker("notif.time", selection: time(hour: $s.reminderHour, minute: $s.reminderMinute),
                               displayedComponents: .hourAndMinute)
                }
                Toggle("notif.summaryToggle", isOn: $s.summaryOn)
                if s.summaryOn {
                    DatePicker("notif.time", selection: time(hour: $s.summaryHour, minute: $s.summaryMinute),
                               displayedComponents: .hourAndMinute)
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(Theme.background)
        .navigationTitle(Text("prof.notifications"))
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: settings.notificationSignature) { _, _ in
            Task {
                if settings.highOn || settings.lowOn || settings.reminderOn || settings.summaryOn {
                    let granted = await NotificationService.requestAuthorization()
                    denied = !granted
                }
                if settings.highOn || settings.lowOn { await HealthKitService.shared.enableBackgroundDelivery() }
                await NotificationService.reschedule()
            }
        }
        .task { denied = await NotificationService.status() == .denied }
    }

    private func time(hour: Binding<Int>, minute: Binding<Int>) -> Binding<Date> {
        Binding {
            Calendar.current.date(from: DateComponents(hour: hour.wrappedValue, minute: minute.wrappedValue)) ?? .now
        } set: { new in
            let c = Calendar.current.dateComponents([.hour, .minute], from: new)
            hour.wrappedValue = c.hour ?? 9
            minute.wrappedValue = c.minute ?? 0
        }
    }
}

struct PrivacyView: View {
    @Environment(HealthDataStore.self) private var store
    @Environment(\.modelContext) private var context
    @Environment(\.openURL) private var openURL
    @Query private var favorites: [FavoriteReading]
    @Query private var profiles: [UserProfile]
    @State private var confirmDelete = false

    var body: some View {
        List {
            Section("privacy.stored") {
                Text("privacy.storedBody").font(.subheadline)
            }
            Section("privacy.permissions") {
                Text("privacy.permissionsBody").font(.subheadline)
                Button { open("x-apple-health://") } label: { Label("common.openHealth", systemImage: "heart.text.square") }
                Button { open(UIApplication.openSettingsURLString) } label: { Label("common.openSettings", systemImage: "gearshape") }
            }
            Section("privacy.sources") {
                if store.sources.isEmpty {
                    Text("privacy.noSources").font(.footnote).foregroundStyle(Theme.textSecondary)
                } else {
                    ForEach(store.sources, id: \.self) { Label($0, systemImage: "applewatch") }
                }
                Text("privacy.sourcesNote").font(.caption).foregroundStyle(Theme.textSecondary)
            }
            Section("privacy.upload") {
                Text("privacy.uploadBody").font(.subheadline)
            }
            Section {
                Button("privacy.delete", role: .destructive) { confirmDelete = true }
            }
        }
        .scrollContentBackground(.hidden)
        .background(Theme.background)
        .navigationTitle(Text("prof.privacy"))
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("privacy.deleteConfirm", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("privacy.delete", role: .destructive) {
                for favorite in favorites { context.delete(favorite) }
                for profile in profiles { profile.name = ""; profile.birthYear = nil }
                Haptics.success()
            }
        }
    }

    private func open(_ s: String) { if let u = URL(string: s) { openURL(u) } }
}

struct ExportReportView: View {
    @Environment(HealthDataStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @Query private var profiles: [UserProfile]
    @State private var range: TimeRange = .week
    @State private var url: URL?
    @State private var working = false
    @State private var failed = false

    private let options: [TimeRange] = [.week, .month, .sixMonths]

    var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                Text("export.body").font(.subheadline).foregroundStyle(Theme.textSecondary)
                Picker("an.range", selection: $range) {
                    ForEach(options) { Text(LocalizedStringKey($0.titleKey)).tag($0) }
                }
                .pickerStyle(.segmented)
                .onChange(of: range) { _, _ in url = nil }

                if working { ECGLoader() }
                if failed { Text("export.failed").foregroundStyle(Theme.heart) }

                if let url {
                    ShareLink(item: url) { Label("export.share", systemImage: "square.and.arrow.up") }
                        .buttonStyle(GoldButtonStyle())
                } else {
                    Button { Task { await generate() } } label: { Text("export.generate") }
                        .buttonStyle(GoldButtonStyle())
                        .disabled(working || store.access != .ready)
                }
                if store.access != .ready {
                    Text("an.needsAccess").font(.footnote).foregroundStyle(Theme.textSecondary)
                }
                Spacer()
            }
            .padding(24)
            .background(Theme.background.ignoresSafeArea())
            .navigationTitle(Text("home.export"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("common.done") { dismiss() } } }
        }
        .presentationDetents([.medium])
    }

    private func generate() async {
        working = true; failed = false
        defer { working = false }
        let service = HealthKitService.shared
        let stats = (try? await service.overall(.heartRate, from: range.start(), to: .now)) ?? nil
        let resting = (try? await service.overall(.resting, from: range.start(), to: .now)) ?? nil
        let buckets = (try? await service.buckets(.heartRate, range: range)) ?? []
        let data = ReportData(
            name: profiles.first?.name ?? "", age: profiles.first?.age, range: range,
            stats: stats, restingAvg: resting?.avg, buckets: buckets, insights: store.insights)
        do {
            url = try PDFReportExporter.make(data)
            Haptics.success()
        } catch {
            failed = true
        }
    }
}
