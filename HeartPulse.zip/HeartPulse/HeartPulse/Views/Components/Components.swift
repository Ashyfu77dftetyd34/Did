import SwiftUI
import Charts

// MARK: - Custom ECG icon & loader

struct ECGShape: Shape {
    func path(in rect: CGRect) -> Path {
        let w = rect.width, h = rect.height, mid = rect.midY
        var p = Path()
        p.move(to: CGPoint(x: 0, y: mid))
        p.addLine(to: CGPoint(x: w * 0.22, y: mid))
        p.addQuadCurve(to: CGPoint(x: w * 0.34, y: mid), control: CGPoint(x: w * 0.28, y: mid - h * 0.16))
        p.addLine(to: CGPoint(x: w * 0.42, y: mid))
        p.addLine(to: CGPoint(x: w * 0.47, y: mid + h * 0.12))
        p.addLine(to: CGPoint(x: w * 0.54, y: mid - h * 0.48))
        p.addLine(to: CGPoint(x: w * 0.61, y: mid + h * 0.36))
        p.addLine(to: CGPoint(x: w * 0.66, y: mid))
        p.addLine(to: CGPoint(x: w * 0.76, y: mid))
        p.addQuadCurve(to: CGPoint(x: w * 0.9, y: mid), control: CGPoint(x: w * 0.83, y: mid - h * 0.22))
        p.addLine(to: CGPoint(x: w, y: mid))
        return p
    }
}

struct ECGLoader: View {
    var height: CGFloat = 44
    @State private var phase: CGFloat = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            ECGShape().stroke(Theme.hairline, style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
            ECGShape()
                .trim(from: max(0, phase - 0.3), to: phase)
                .stroke(Theme.heart, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                .shadow(color: Theme.heart.opacity(0.6), radius: 6)
        }
        .frame(width: height * 3, height: height)
        .onAppear {
            guard !reduceMotion else { phase = 1; return }
            withAnimation(.linear(duration: 1.6).repeatForever(autoreverses: false)) { phase = 1.3 }
        }
        .accessibilityLabel(Text("common.loading"))
    }
}

// MARK: - Animated heart

/// Beats in rhythm with the latest reading only when that reading is live/recent.
/// Otherwise it only "breathes" slowly, so an old value is never presented as live.
struct HeartPulseIcon: View {
    var bpm: Double?
    var size: CGFloat = 150
    @State private var beating = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            Circle()
                .strokeBorder(LinearGradient(colors: [Theme.gold.opacity(0.7), Theme.gold.opacity(0.05)],
                                             startPoint: .top, endPoint: .bottom), lineWidth: 1)
                .frame(width: size * 1.25, height: size * 1.25)
                .scaleEffect(beating ? 1.06 : 1)
                .opacity(beating ? 0.5 : 1)
            Circle()
                .fill(RadialGradient(colors: [Theme.heart.opacity(0.28), .clear],
                                     center: .center, startRadius: 4, endRadius: size * 0.7))
                .frame(width: size * 1.2, height: size * 1.2)
            Image(systemName: "heart.fill")
                .font(.system(size: size * 0.46))
                .foregroundStyle(LinearGradient(colors: [Theme.heart, Theme.heart.opacity(0.65)],
                                                startPoint: .top, endPoint: .bottom))
                .shadow(color: Theme.heart.opacity(0.5), radius: 18, y: 4)
                .scaleEffect(beating ? 1.1 : 1)
        }
        .frame(width: size * 1.3, height: size * 1.3)
        .accessibilityHidden(true)
        .task(id: bpm) { await animate() }
    }

    private func animate() async {
        guard !reduceMotion else { return }
        if let bpm, bpm > 0 {
            let period = 60.0 / min(max(bpm, 30), 220)
            while !Task.isCancelled {
                withAnimation(.easeOut(duration: period * 0.25)) { beating = true }
                try? await Task.sleep(for: .seconds(period * 0.25))
                withAnimation(.easeIn(duration: period * 0.75)) { beating = false }
                try? await Task.sleep(for: .seconds(period * 0.75))
            }
        } else {
            while !Task.isCancelled {
                withAnimation(.easeInOut(duration: 2.4)) { beating = true }
                try? await Task.sleep(for: .seconds(2.4))
                withAnimation(.easeInOut(duration: 2.4)) { beating = false }
                try? await Task.sleep(for: .seconds(2.4))
            }
        }
    }
}

// MARK: - Small building blocks

struct StatTile: View {
    let titleKey: LocalizedStringKey
    let value: String
    let icon: String
    var tint: Color = Theme.gold

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.footnote).foregroundStyle(tint)
                Text(titleKey).font(.footnote).foregroundStyle(Theme.textSecondary)
                Spacer(minLength: 0)
            }
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(value)
                    .font(Theme.number(34))
                    .monospacedDigit()
                    .foregroundStyle(Theme.textPrimary)
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
                Text("common.bpm").font(.caption).foregroundStyle(Theme.textSecondary)
            }
        }
        .premiumCard(padding: 16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }
}

struct SectionTitle: View {
    let key: LocalizedStringKey
    var body: some View {
        Text(key)
            .font(Theme.title(20))
            .foregroundStyle(Theme.textPrimary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityAddTraits(.isHeader)
    }
}

struct FreshnessBadge: View {
    let freshness: Freshness?

    private var config: (key: LocalizedStringKey, color: Color) {
        switch freshness {
        case .live: ("fresh.live", Theme.heart)
        case .recent: ("fresh.recent", Theme.gold)
        case .recorded: ("fresh.recorded", Theme.textSecondary)
        case nil: ("fresh.none", Theme.textSecondary)
        }
    }

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(config.color).frame(width: 7, height: 7)
            Text(config.key).font(.caption.weight(.semibold))
        }
        .foregroundStyle(config.color)
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Capsule().fill(config.color.opacity(0.12)))
    }
}

struct EmptyStateCard: View {
    let icon: String
    let titleKey: LocalizedStringKey
    let bodyKey: LocalizedStringKey
    var actionKey: LocalizedStringKey?
    var action: (() -> Void)?

    var body: some View {
        VStack(spacing: 14) {
            ECGShape()
                .stroke(Theme.gold.opacity(0.7), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                .frame(width: 120, height: 36)
            Image(systemName: icon).font(.title2).foregroundStyle(Theme.gold)
            Text(titleKey).font(Theme.title(20)).multilineTextAlignment(.center)
            Text(bodyKey).font(.subheadline).foregroundStyle(Theme.textSecondary).multilineTextAlignment(.center)
            if let actionKey, let action {
                Button(action: { Haptics.tap(); action() }) { Text(actionKey) }
                    .buttonStyle(GoldButtonStyle())
                    .padding(.top, 4)
            }
        }
        .frame(maxWidth: .infinity)
        .premiumCard(padding: 24)
    }
}

struct InsightCard: View {
    let insight: Insight

    private var tint: Color {
        switch insight.tone {
        case .attention: Theme.heart
        case .positive: Theme.gold
        case .neutral: Theme.textSecondary
        }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: insight.icon)
                .font(.title3)
                .foregroundStyle(tint)
                .frame(width: 40, height: 40)
                .background(Circle().fill(tint.opacity(0.12)))
            VStack(alignment: .leading, spacing: 4) {
                Text(insight.title).font(.headline).foregroundStyle(Theme.textPrimary)
                Text(insight.body).font(.subheadline).foregroundStyle(Theme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .premiumCard(padding: 16)
        .accessibilityElement(children: .combine)
    }
}

struct DisclaimerFootnote: View {
    var body: some View {
        Text("common.disclaimer")
            .font(.caption)
            .foregroundStyle(Theme.textSecondary)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 8)
    }
}

// MARK: - Chart

struct HeartChart: View {
    let buckets: [HeartBucket]
    let range: TimeRange
    var showBand = true
    var height: CGFloat = 200
    @State private var selectedDate: Date?

    private var selected: HeartBucket? {
        guard let s = selectedDate else { return nil }
        return buckets.min { abs($0.date.timeIntervalSince(s)) < abs($1.date.timeIntervalSince(s)) }
    }

    private var yDomain: ClosedRange<Double> {
        let lows = buckets.map { showBand ? $0.min : $0.avg }
        let highs = buckets.map { showBand ? $0.max : $0.avg }
        let lo = lows.min() ?? 50, hi = highs.max() ?? 120
        return max(0, (floor((lo - 8) / 10) * 10))...(ceil((hi + 8) / 10) * 10)
    }

    var body: some View {
        Group {
            if buckets.isEmpty {
                VStack(spacing: 8) {
                    ECGShape().stroke(Theme.hairline, lineWidth: 2).frame(width: 110, height: 32)
                    Text("common.noData").font(.footnote).foregroundStyle(Theme.textSecondary)
                }
                .frame(maxWidth: .infinity, minHeight: height)
            } else {
                Chart {
                    ForEach(buckets) { b in
                        if showBand {
                            AreaMark(x: .value("Time", b.date),
                                     yStart: .value("Min", b.min), yEnd: .value("Max", b.max))
                                .foregroundStyle(Theme.heart.opacity(0.14))
                                .interpolationMethod(.monotone)
                        }
                        LineMark(x: .value("Time", b.date), y: .value("Average", b.avg))
                            .foregroundStyle(Theme.heart)
                            .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round))
                            .interpolationMethod(.monotone)
                        PointMark(x: .value("Time", b.date), y: .value("Average", b.avg))
                            .foregroundStyle(Theme.heart)
                            .symbolSize(buckets.count > 40 ? 0 : 26)
                    }
                    if let sel = selected {
                        RuleMark(x: .value("Selected", sel.date))
                            .foregroundStyle(Theme.gold.opacity(0.7))
                            .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                            .annotation(position: .top, overflowResolution: .init(x: .fit, y: .disabled)) {
                                VStack(spacing: 2) {
                                    Text("\(Fmt.bpm(sel.avg)) \(Loc.t("common.bpm"))").font(.caption.weight(.bold))
                                    Text("\(Fmt.bpm(sel.min))–\(Fmt.bpm(sel.max))").font(.caption2)
                                        .foregroundStyle(Theme.textSecondary)
                                    Text(range == .day ? Fmt.time(sel.date) : Fmt.dayShort(sel.date))
                                        .font(.caption2).foregroundStyle(Theme.textSecondary)
                                }
                                .padding(8)
                                .background(RoundedRectangle(cornerRadius: 10).fill(Theme.surfaceRaised))
                            }
                    }
                }
                .chartXSelection(value: $selectedDate)
                .chartYScale(domain: yDomain)
                .chartXScale(domain: range.start()...range.end())
                .chartXAxis {
                    AxisMarks(values: .automatic(desiredCount: 5)) { _ in
                        AxisGridLine().foregroundStyle(Theme.hairline)
                        AxisValueLabel(format: range.axisFormat).foregroundStyle(Theme.textSecondary)
                    }
                }
                .chartYAxis {
                    AxisMarks(position: .leading) { _ in
                        AxisGridLine().foregroundStyle(Theme.hairline)
                        AxisValueLabel().foregroundStyle(Theme.textSecondary)
                    }
                }
                .frame(height: height)
                .onChange(of: selectedDate) { _, new in if new != nil { Haptics.select() } }
                .accessibilityLabel(Text("common.chartLabel"))
            }
        }
    }
}
