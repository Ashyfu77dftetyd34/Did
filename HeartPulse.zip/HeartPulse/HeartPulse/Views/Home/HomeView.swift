import SwiftUI
import SwiftData

struct HomeView: View {
    @Environment(HealthDataStore.self) private var store
    @Query private var profiles: [UserProfile]
    @State private var showExport = false
    var navigate: (AppTab) -> Void

    private var age: Int? { profiles.first?.age }

    var body: some View {
        ScrollView {
            VStack(spacing: 22) {
                header
                switch store.access {
                case .loading:
                    ECGLoader().padding(.top, 80)
                case .unavailable:
                    EmptyStateCard(icon: "iphone.slash", titleKey: "state.unavailable.title",
                                   bodyKey: "state.unavailable.body")
                case .needsPermission:
                    EmptyStateCard(icon: "heart.text.square", titleKey: "state.connect.title",
                                   bodyKey: "state.connect.body", actionKey: "state.connect.action") {
                        Task { await store.requestAccess(age: age) }
                    }
                case .ready:
                    readyContent
                }
                DisclaimerFootnote()
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 130)
        }
        .scrollIndicators(.hidden)
        .refreshable { await store.refresh(age: age) }
        .sheet(isPresented: $showExport) { ExportReportView() }
    }

    // MARK: Pieces

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            let name = profiles.first?.name ?? ""
            Text(name.isEmpty ? Loc.t("home.greeting") : Loc.t("home.greetingName", [name]))
                .font(.subheadline)
                .foregroundStyle(Theme.textSecondary)
            Text("home.title").font(Theme.title(32)).foregroundStyle(Theme.textPrimary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    @ViewBuilder private var readyContent: some View {
        hero
        statsGrid
        VStack(spacing: 12) {
            SectionTitle(key: "home.todayChart")
            HeartChart(buckets: store.todayHourly, range: .day, height: 180)
                .premiumCard(padding: 14)
        }
        quickActions
        if let first = store.insights.first {
            VStack(spacing: 12) {
                SectionTitle(key: "home.insight")
                InsightCard(insight: first)
                    .onTapGesture { navigate(.analytics) }
            }
        }
    }

    private var hero: some View {
        let fresh = store.freshness
        let animated = (fresh == .live || fresh == .recent) ? store.latest?.bpm : nil
        return VStack(spacing: 6) {
            HeartPulseIcon(bpm: animated, size: 130)
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(Fmt.bpm(store.latest?.bpm))
                    .font(Theme.number(96))
                    .monospacedDigit()
                    .foregroundStyle(Theme.textPrimary)
                    .contentTransition(.numericText())
                    .minimumScaleFactor(0.6)
                Text("common.bpm").font(.title3).foregroundStyle(Theme.gold)
            }
            .animation(.smooth, value: store.latest?.bpm)
            FreshnessBadge(freshness: fresh)
            if let latest = store.latest {
                Text(Loc.t("home.lastMeasured", [Fmt.relative(latest.date), Fmt.time(latest.date)]))
                    .font(.footnote).foregroundStyle(Theme.textSecondary)
                if let statusKey = statusKey(latest) {
                    Text(LocalizedStringKey(statusKey))
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(Theme.textPrimary)
                        .padding(.top, 2)
                }
            } else {
                Text("home.noReadings").font(.footnote).foregroundStyle(Theme.textSecondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .premiumCard(padding: 20)
        .accessibilityElement(children: .combine)
    }

    private func statusKey(_ s: HeartRateSample) -> String? {
        if s.context == .active { return "status.active" }
        if s.bpm < 60 { return "status.low" }
        if s.bpm > 100 { return "status.high" }
        return "status.typical"
    }

    private var statsGrid: some View {
        let stats = store.todayStats
        return LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            StatTile(titleKey: "home.dailyAverage", value: Fmt.bpm(stats?.avg), icon: "chart.bar")
            StatTile(titleKey: "common.resting", value: Fmt.bpm(store.resting?.bpm), icon: "bed.double", tint: Theme.heart)
            StatTile(titleKey: "common.minimum", value: Fmt.bpm(stats?.min), icon: "arrow.down.to.line")
            StatTile(titleKey: "common.maximum", value: Fmt.bpm(stats?.max), icon: "arrow.up.to.line")
        }
    }

    private var quickActions: some View {
        VStack(spacing: 12) {
            SectionTitle(key: "home.quick")
            HStack(spacing: 12) {
                action("tab.heartRate", "heart.text.square") { navigate(.heartRate) }
                action("tab.analytics", "chart.xyaxis.line") { navigate(.analytics) }
                action("tab.history", "clock.arrow.circlepath") { navigate(.history) }
                action("home.export", "doc.richtext") { Haptics.tap(); showExport = true }
            }
        }
    }

    private func action(_ key: String, _ icon: String, _ run: @escaping () -> Void) -> some View {
        Button(action: run) {
            VStack(spacing: 8) {
                Image(systemName: icon).font(.title3).foregroundStyle(Theme.gold)
                Text(LocalizedStringKey(key))
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(Theme.textPrimary)
                    .lineLimit(1).minimumScaleFactor(0.7)
            }
            .frame(maxWidth: .infinity)
            .premiumCard(padding: 14)
        }
        .buttonStyle(.plain)
    }
}
