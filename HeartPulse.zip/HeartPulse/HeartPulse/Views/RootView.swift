import SwiftUI
import SwiftData

struct RootView: View {
    @Environment(HealthDataStore.self) private var store
    @Environment(AppSettings.self) private var settings
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase
    @Query private var profiles: [UserProfile]
    @State private var tab: AppTab = .home

    private var age: Int? { profiles.first?.age }

    var body: some View {
        ZStack(alignment: .bottom) {
            Theme.background.ignoresSafeArea()

            Group {
                switch tab {
                case .home: HomeView(navigate: { go($0) })
                case .heartRate: HeartRateView()
                case .analytics: AnalyticsView()
                case .history: HistoryView()
                case .profile: ProfileView()
                }
            }
            .transition(.opacity.combined(with: .scale(scale: 0.985)))
            .id(tab)

            CustomTabBar(selection: $tab)
        }
        .animation(.smooth(duration: 0.3), value: tab)
        .task {
            if profiles.isEmpty { context.insert(UserProfile()) }
            await store.bootstrap(age: age)
            await NotificationService.reschedule()
        }
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .active:
                Task {
                    await store.refresh(age: age)
                    store.startLive()
                }
            case .background:
                store.stopLive()
            default: break
            }
        }
    }

    private func go(_ t: AppTab) {
        Haptics.tap()
        tab = t
    }
}

struct CustomTabBar: View {
    @Binding var selection: AppTab
    @Namespace private var ns

    var body: some View {
        HStack(spacing: 2) {
            ForEach(AppTab.allCases) { item in
                Button {
                    guard selection != item else { return }
                    Haptics.select()
                    selection = item
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: selection == item ? item.icon + ".fill" : item.icon)
                            .font(.system(size: 19, weight: .medium))
                            .symbolRenderingMode(.monochrome)
                        Text(LocalizedStringKey(item.titleKey))
                            .font(.system(size: 10, weight: .semibold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                    }
                    .foregroundStyle(selection == item ? Theme.gold : Theme.textSecondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background {
                        if selection == item {
                            Capsule()
                                .fill(Theme.gold.opacity(0.14))
                                .overlay(Capsule().strokeBorder(Theme.gold.opacity(0.35), lineWidth: 1))
                                .matchedGeometryEffect(id: "tab-indicator", in: ns)
                        }
                    }
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(Text(LocalizedStringKey(item.titleKey)))
                .accessibilityAddTraits(selection == item ? [.isSelected, .isButton] : .isButton)
            }
        }
        .padding(6)
        .background {
            Capsule()
                .fill(.ultraThinMaterial)
                .overlay(Capsule().strokeBorder(
                    LinearGradient(colors: [Theme.gold.opacity(0.45), Theme.hairline],
                                   startPoint: .top, endPoint: .bottom), lineWidth: 1))
                .shadow(color: .black.opacity(0.2), radius: 18, y: 8)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 6)
        .animation(.smooth(duration: 0.3), value: selection)
    }
}
