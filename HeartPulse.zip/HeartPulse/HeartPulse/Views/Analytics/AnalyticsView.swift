import SwiftUI
import Charts

struct AnalyticsView: View {
    @Environment(HealthDataStore.self) private var store
    @State private var vm = AnalyticsViewModel()
    @State private var range: TimeRange = .week

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("an.title").font(Theme.title(32)).frame(maxWidth: .infinity, alignment: .leading)

                Picker("an.range", selection: $range) {
                    ForEach(TimeRange.allCases) { r in Text(LocalizedStringKey(r.titleKey)).tag(r) }
                }
                .pickerStyle(.segmented)
                .onChange(of: range) { _, _ in Haptics.select() }

                if store.access != .ready {
                    EmptyStateCard(icon: "chart.xyaxis.line", titleKey: "state.connect.title",
                                   bodyKey: "an.needsAccess")
                } else {
                    content
                }
                DisclaimerFootnote()
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 130)
        }
        .scrollIndicators(.hidden)
        .task(id: range) {
            guard store.access == .ready else { return }
            await vm.load(range: range)
        }
    }

    @ViewBuilder private var content: some View {
        if vm.isLoading && vm.buckets.isEmpty {
            ECGLoader().padding(.top, 40)
        }

        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            StatTile(titleKey: "common.average", value: Fmt.bpm(vm.stats?.avg), icon: "chart.bar")
            StatTile(titleKey: "an.restingAvg", value: Fmt.bpm(vm.restingStats?.avg), icon: "bed.double", tint: Theme.heart)
            StatTile(titleKey: "an.lowest", value: Fmt.bpm(vm.stats?.min), icon: "arrow.down.to.line")
            StatTile(titleKey: "an.highest", value: Fmt.bpm(vm.stats?.max), icon: "arrow.up.to.line")
        }

        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(key: LocalizedStringKey(chartTitleKey))
            HeartChart(buckets: vm.buckets, range: range, height: 220).premiumCard(padding: 14)
            Text("an.chartHint").font(.caption).foregroundStyle(Theme.textSecondary)
        }

        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(key: "an.restingTrend")
            restingChart.premiumCard(padding: 14)
        }

        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(key: "an.exercise")
            exerciseChart.premiumCard(padding: 14)
        }

        VStack(spacing: 12) {
            SectionTitle(key: "an.insights")
            if store.insights.isEmpty {
                Text("an.noInsights").font(.subheadline).foregroundStyle(Theme.textSecondary)
                    .multilineTextAlignment(.center).frame(maxWidth: .infinity).premiumCard()
            } else {
                ForEach(store.insights) { InsightCard(insight: $0) }
            }
        }
    }

    private var chartTitleKey: String {
        switch range {
        case .day: "an.hourly"
        case .week, .month: "an.daily"
        case .sixMonths: "an.weekly"
        case .year: "an.monthly"
        }
    }

    private var restingChart: some View {
        let r = range.restingRange
        return Group {
            if vm.resting.isEmpty {
                Text("an.noResting").font(.footnote).foregroundStyle(Theme.textSecondary)
                    .frame(maxWidth: .infinity, minHeight: 100)
            } else {
                Chart(vm.resting) { b in
                    LineMark(x: .value("Date", b.date), y: .value("Resting", b.avg))
                        .foregroundStyle(Theme.gold).interpolationMethod(.monotone)
                        .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round))
                    PointMark(x: .value("Date", b.date), y: .value("Resting", b.avg))
                        .foregroundStyle(Theme.gold).symbolSize(vm.resting.count > 40 ? 0 : 28)
                }
                .chartYScale(domain: .automatic(includesZero: false))
                .chartXScale(domain: r.start()...r.end())
                .chartXAxis {
                    AxisMarks(values: .automatic(desiredCount: 5)) { _ in
                        AxisGridLine().foregroundStyle(Theme.hairline)
                        AxisValueLabel(format: r.axisFormat).foregroundStyle(Theme.textSecondary)
                    }
                }
                .chartYAxis {
                    AxisMarks(position: .leading) { _ in
                        AxisGridLine().foregroundStyle(Theme.hairline)
                        AxisValueLabel().foregroundStyle(Theme.textSecondary)
                    }
                }
                .frame(height: 150)
            }
        }
    }

    private var exerciseChart: some View {
        Group {
            if vm.workouts.isEmpty {
                Text("an.noExercise").font(.footnote).foregroundStyle(Theme.textSecondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity, minHeight: 100)
            } else {
                VStack(alignment: .leading, spacing: 12) {
                    Chart(vm.workouts) { w in
                        BarMark(x: .value("Date", w.date, unit: .day), y: .value("Average", w.avg))
                            .foregroundStyle(Theme.heart.opacity(0.85)).cornerRadius(4)
                        PointMark(x: .value("Date", w.date, unit: .day), y: .value("Peak", w.max))
                            .foregroundStyle(Theme.gold).symbolSize(40)
                    }
                    .chartYScale(domain: .automatic(includesZero: false))
                    .chartYAxis {
                        AxisMarks(position: .leading) { _ in
                            AxisGridLine().foregroundStyle(Theme.hairline)
                            AxisValueLabel().foregroundStyle(Theme.textSecondary)
                        }
                    }
                    .frame(height: 150)
                    HStack(spacing: 16) {
                        legend(Theme.heart, "an.legendAvg")
                        legend(Theme.gold, "an.legendPeak")
                    }
                    ForEach(vm.workouts.suffix(5).reversed()) { w in
                        HStack {
                            Text(LocalizedStringKey(w.nameKey)).font(.subheadline.weight(.medium))
                            Text("· \(Fmt.dayShort(w.date)) · \(Loc.t("an.minutes", [Int(w.duration / 60)]))")
                                .font(.caption).foregroundStyle(Theme.textSecondary)
                            Spacer()
                            Text("\(Fmt.bpm(w.avg)) / \(Fmt.bpm(w.max))").font(.subheadline).monospacedDigit()
                        }
                    }
                }
            }
        }
    }

    private func legend(_ color: Color, _ key: LocalizedStringKey) -> some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 8, height: 8)
            Text(key).font(.caption).foregroundStyle(Theme.textSecondary)
        }
    }
}
