import SwiftUI
import SwiftData

struct OnboardingView: View {
    @Environment(AppSettings.self) private var settings
    @Environment(HealthDataStore.self) private var store
    @Environment(\.modelContext) private var context
    @State private var page = 0
    @State private var name = ""
    @State private var birthYear: Int?
    private let years = Array((1920...Calendar.current.component(.year, from: .now)).reversed())

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    Spacer()
                    Menu {
                        Picker("prof.language", selection: Bindable(settings).language) {
                            Text("prof.system").tag("system")
                            Text(verbatim: "English").tag("en")
                            Text(verbatim: "العربية").tag("ar")
                        }
                    } label: {
                        Image(systemName: "globe").font(.title3).foregroundStyle(Theme.gold)
                    }
                    .accessibilityLabel(Text("prof.language"))
                }
                .padding(.horizontal, 24).padding(.top, 8)

                TabView(selection: $page) {
                    pageView(icon: nil, title: "onb.1.title", body: "onb.1.body").tag(0)
                    pageView(icon: "applewatch", title: "onb.2.title", body: "onb.2.body").tag(1)
                    pageView(icon: "lock.shield", title: "onb.3.title", body: "onb.3.body").tag(2)
                    profilePage.tag(3)
                }
                .tabViewStyle(.page(indexDisplayMode: .always))

                Button {
                    Haptics.tap()
                    if page < 3 { withAnimation(.smooth) { page += 1 } } else { Task { await finish() } }
                } label: {
                    Text(page < 3 ? "common.next" : "onb.connect")
                }
                .buttonStyle(GoldButtonStyle())
                .padding(.horizontal, 28)
                .padding(.bottom, 12)

                if page == 3 {
                    Button("onb.skip") { Task { await finish(requestAccess: false) } }
                        .font(.footnote).foregroundStyle(Theme.textSecondary).padding(.bottom, 12)
                }
            }
        }
    }

    private func pageView(icon: String?, title: LocalizedStringKey, body: LocalizedStringKey) -> some View {
        VStack(spacing: 22) {
            Spacer()
            if let icon {
                Image(systemName: icon).font(.system(size: 64)).foregroundStyle(Theme.gold)
                    .frame(height: 140)
            } else {
                HeartPulseIcon(bpm: nil, size: 110)
            }
            Text(title).font(Theme.title(30)).multilineTextAlignment(.center)
            Text(body).font(.body).foregroundStyle(Theme.textSecondary).multilineTextAlignment(.center)
            Spacer()
            Spacer()
        }
        .padding(.horizontal, 32)
    }

    private var profilePage: some View {
        VStack(spacing: 18) {
            Spacer()
            Text("onb.4.title").font(Theme.title(30)).multilineTextAlignment(.center)
            Text("onb.4.body").font(.subheadline).foregroundStyle(Theme.textSecondary).multilineTextAlignment(.center)
            VStack(spacing: 0) {
                TextField("prof.name", text: $name).padding()
                Divider().overlay(Theme.hairline)
                Picker("prof.birthYear", selection: $birthYear) {
                    Text(verbatim: "—").tag(Int?.none)
                    ForEach(years, id: \.self) { y in Text(verbatim: String(y)).tag(Int?.some(y)) }
                }
                .padding(.horizontal)
                .padding(.vertical, 6)
            }
            .premiumCard(padding: 0)
            Text("onb.4.note").font(.footnote).foregroundStyle(Theme.textSecondary).multilineTextAlignment(.center)
            Spacer()
            Spacer()
        }
        .padding(.horizontal, 28)
    }

    private func finish(requestAccess: Bool = true) async {
        let profile = UserProfile(name: name.trimmingCharacters(in: .whitespaces), birthYear: birthYear)
        context.insert(profile)
        if requestAccess { await store.requestAccess(age: profile.age) }
        Haptics.success()
        withAnimation(.smooth) { settings.onboarded = true }
        AlertMonitor.start()
    }
}
