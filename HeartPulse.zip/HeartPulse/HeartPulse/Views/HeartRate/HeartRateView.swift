import SwiftUI
import SwiftData

struct HeartRateView: View {
    @Environment(HealthDataStore.self) private var store
    @Environment(\.modelContext) private var context
    @Environment(\.openURL) private var openURL
    @Query private var profiles: [UserProfile]
    @Query private var favorites: [FavoriteReading]
    @State private var savedTick = 0

    private var maxHR: Double? { profiles.first?.estimatedMaxHR }
    private var age: Int? { profiles.first?.age }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("hr.title").font(Theme.title(32)).frame(maxWidth: .infinity, alignment: .leading)

                switch store.access {
                case .loading: ECGLoader().padding(.top, 60)
                case .unavailable:
                    EmptyStateCard(icon: "iphone.slash", titleKey: "state.unavailable.title", bodyKey: "state.unavailable.body")
                case .needsPermission:
                    EmptyStateCard(icon: "heart.text.square", titleKey: "state.connect.title",
                                   bodyKey: "state.connect.body", actionKey: "state.connect.action") {
                        Task { await store.requestAccess(age: age) }
                    }
                case .ready:
                    latestCard
                    zonesCard
                    recentList
                    sourceCard
                    experimentalCard
                }
                DisclaimerFootnote()
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 130)
        }
        .scrollIndicators(.hidden)
        .refreshable { await store.refresh(age: age) }
        .sensoryFeedback(.success, trigger: savedTick)
    }

    private var latestCard: some View {
        let fresh = store.freshness
        return VStack(spacing: 10) {
            FreshnessBadge(freshness: fresh)
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(Fmt.bpm(store.latest?.bpm))
                    .font(Theme.number(88)).monospacedDigit().contentTransition(.numericText())
                Text("common.bpm").font(.title3).foregroundStyle(Theme.gold)
            }
            .animation(.smooth, value: store.latest?.bpm)
            if let l = store.latest {
                Text(Loc.t("hr.measuredAt", [Fmt.dayShort(l.date), Fmt.time(l.date)]))
                    .font(.footnote).foregroundStyle(Theme.textSecondary)
                Text(Loc.t("hr.from", [l.source])).font(.footnote).foregroundStyle(Theme.textSecondary)
                if fresh == .recorded {
                    Text("hr.recordedNote").font(.footnote).foregroundStyle(Theme.textSecondary)
                        .multilineTextAlignment(.center)
                }
                Button {
                    toggleFavorite(l)
                } label: {
                    Label(isFavorite(l) ? "hr.saved" : "hr.save", systemImage: isFavorite(l) ? "star.fill" : "star")
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 16).padding(.vertical, 9)
                        .background(Capsule().fill(Theme.gold.opacity(0.14)))
                        .foregroundStyle(Theme.gold)
                }
                .buttonStyle(.plain)
            } else {
                Text("home.noReadings").font(.footnote).foregroundStyle(Theme.textSecondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .premiumCard(padding: 22)
    }

    private var zonesCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("hr.zones").font(.headline)
            if let maxHR, let l = store.latest {
                let current = HeartZone.zone(bpm: l.bpm, maxHR: maxHR)
                HStack(spacing: 5) {
                    ForEach(HeartZone.allCases, id: \.rawValue) { z in
                        Capsule()
                            .fill(z == current ? Theme.heart : Theme.hairline)
                            .frame(height: z == current ? 12 : 8)
                    }
                }
                .animation(.smooth, value: current)
                Text(Loc.t("hr.zoneNow", [Loc.t(current.titleKey), Int(maxHR)]))
                    .font(.footnote).foregroundStyle(Theme.textSecondary)
            } else {
                Text("hr.zonesNeedAge").font(.footnote).foregroundStyle(Theme.textSecondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .premiumCard()
    }

    private var recentList: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(key: "hr.recent")
            let items = Array(store.today.suffix(12).reversed())
            if items.isEmpty {
                Text("hr.noneToday").font(.footnote).foregroundStyle(Theme.textSecondary)
                    .frame(maxWidth: .infinity).premiumCard()
            } else {
                VStack(spacing: 0) {
                    ForEach(items) { s in
                        ReadingRow(sample: s, isFavorite: isFavorite(s)) { toggleFavorite(s) }
                        if s.id != items.last?.id { Divider().overlay(Theme.hairline) }
                    }
                }
                .premiumCard(padding: 14)
            }
        }
    }

    private var sourceCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("hr.sourceTitle", systemImage: "applewatch").font(.headline)
            Text("hr.sourceBody").font(.subheadline).foregroundStyle(Theme.textSecondary)
            Button {
                if let url = URL(string: "x-apple-health://") { openURL(url) }
            } label: {
                Label("common.openHealth", systemImage: "heart.text.square")
                    .font(.subheadline.weight(.semibold))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .premiumCard()
    }

    private var experimentalCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("hr.cameraTitle", systemImage: "camera.metering.unknown").font(.headline)
            Text("hr.cameraBody").font(.subheadline).foregroundStyle(Theme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .premiumCard()
    }

    private func isFavorite(_ s: HeartRateSample) -> Bool { favorites.contains { $0.sampleID == s.id } }

    private func toggleFavorite(_ s: HeartRateSample) {
        if let existing = favorites.first(where: { $0.sampleID == s.id }) {
            context.delete(existing)
        } else {
            context.insert(FavoriteReading(sample: s))
            savedTick += 1
        }
    }
}

struct ReadingRow: View {
    let sample: HeartRateSample
    let isFavorite: Bool
    var onFavorite: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Text(Fmt.bpm(sample.bpm))
                .font(Theme.number(28)).monospacedDigit()
                .frame(width: 64, alignment: .leading)
            VStack(alignment: .leading, spacing: 2) {
                Text(Fmt.time(sample.date)).font(.subheadline.weight(.medium))
                Text("\(Loc.t(contextKey)) · \(sample.source)")
                    .font(.caption).foregroundStyle(Theme.textSecondary).lineLimit(1)
            }
            Spacer()
            Button(action: onFavorite) {
                Image(systemName: isFavorite ? "star.fill" : "star").foregroundStyle(Theme.gold)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(Text(isFavorite ? "hr.saved" : "hr.save"))
        }
        .padding(.vertical, 8)
        .accessibilityElement(children: .combine)
    }

    private var contextKey: String {
        switch sample.context {
        case .sedentary: "ctx.rest"
        case .active: "ctx.active"
        case .notSet: "ctx.unknown"
        }
    }
}
