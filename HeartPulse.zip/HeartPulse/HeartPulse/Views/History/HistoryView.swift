import SwiftUI
import SwiftData

@MainActor @Observable
final class HistoryViewModel {
    private(set) var samples: [HeartRateSample] = []
    private(set) var isLoading = false
    var days = 7

    func load() async {
        isLoading = true
        defer { isLoading = false }
        let now = Date()
        let start = Calendar.current.startOfDay(for: now.addingTimeInterval(-Double(days - 1) * 86_400))
        samples = (try? await HealthKitService.shared.samples(from: start, to: now, limit: 1500)) ?? []
    }

    struct Day: Identifiable {
        let date: Date
        let items: [HeartRateSample]
        var id: Date { date }
        var stats: HeartStats {
            let v = items.map(\.bpm)
            return HeartStats(avg: v.reduce(0, +) / Double(max(v.count, 1)), min: v.min() ?? 0, max: v.max() ?? 0)
        }
    }

    var grouped: [Day] {
        let cal = Calendar.current
        return Dictionary(grouping: samples) { cal.startOfDay(for: $0.date) }
            .map { Day(date: $0.key, items: $0.value.sorted { $0.date > $1.date }) }
            .sorted { $0.date > $1.date }
    }
}

struct HistoryView: View {
    @Environment(HealthDataStore.self) private var store
    @Environment(\.modelContext) private var context
    @Query(sort: \FavoriteReading.date, order: .reverse) private var favorites: [FavoriteReading]
    @State private var vm = HistoryViewModel()
    @State private var showFavorites = false

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 16, pinnedViews: []) {
                Text("hist.title").font(Theme.title(32)).frame(maxWidth: .infinity, alignment: .leading)

                Picker("hist.filter", selection: $showFavorites) {
                    Text("hist.all").tag(false)
                    Text("hist.favorites").tag(true)
                }
                .pickerStyle(.segmented)
                .onChange(of: showFavorites) { _, _ in Haptics.select() }

                if showFavorites {
                    favoritesList
                } else if store.access != .ready {
                    EmptyStateCard(icon: "clock.arrow.circlepath", titleKey: "state.connect.title", bodyKey: "an.needsAccess")
                } else if vm.isLoading && vm.samples.isEmpty {
                    ECGLoader().padding(.top, 40)
                } else if vm.grouped.isEmpty {
                    EmptyStateCard(icon: "heart.slash", titleKey: "hist.emptyTitle", bodyKey: "hist.emptyBody")
                } else {
                    ForEach(vm.grouped) { day in dayCard(day) }
                    Button {
                        Haptics.tap()
                        vm.days += 7
                        Task { await vm.load() }
                    } label: { Text("hist.loadMore") }
                    .buttonStyle(GoldButtonStyle())
                }
                DisclaimerFootnote()
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 130)
        }
        .scrollIndicators(.hidden)
        .task(id: store.access) {
            if store.access == .ready { await vm.load() }
        }
        .refreshable { await vm.load() }
    }

    private func dayCard(_ day: HistoryViewModel.Day) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(Fmt.dayLong(day.date)).font(.headline)
            // Daily health summary
            HStack {
                summary("common.average", day.stats.avg)
                summary("common.minimum", day.stats.min)
                summary("common.maximum", day.stats.max)
            }
            Divider().overlay(Theme.hairline)
            ForEach(day.items.prefix(40)) { s in
                ReadingRow(sample: s, isFavorite: favorites.contains { $0.sampleID == s.id }) { toggle(s) }
            }
            if day.items.count > 40 {
                Text(Loc.t("hist.more", [day.items.count - 40]))
                    .font(.caption).foregroundStyle(Theme.textSecondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .premiumCard()
    }

    private func summary(_ key: LocalizedStringKey, _ v: Double) -> some View {
        VStack(spacing: 2) {
            Text(key).font(.caption).foregroundStyle(Theme.textSecondary)
            Text(Fmt.bpm(v)).font(Theme.number(26)).monospacedDigit()
        }
        .frame(maxWidth: .infinity)
    }

    @ViewBuilder private var favoritesList: some View {
        if favorites.isEmpty {
            EmptyStateCard(icon: "star", titleKey: "hist.noFavTitle", bodyKey: "hist.noFavBody")
        } else {
            VStack(spacing: 0) {
                ForEach(favorites) { f in
                    HStack(spacing: 12) {
                        Text(Fmt.bpm(f.bpm)).font(Theme.number(28)).monospacedDigit().frame(width: 64, alignment: .leading)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(Fmt.dayShort(f.date)) · \(Fmt.time(f.date))").font(.subheadline.weight(.medium))
                            Text(f.source).font(.caption).foregroundStyle(Theme.textSecondary)
                        }
                        Spacer()
                        Button { context.delete(f) } label: {
                            Image(systemName: "star.fill").foregroundStyle(Theme.gold)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(Text("hr.saved"))
                    }
                    .padding(.vertical, 8)
                    if f.id != favorites.last?.id { Divider().overlay(Theme.hairline) }
                }
            }
            .premiumCard(padding: 14)
        }
    }

    private func toggle(_ s: HeartRateSample) {
        if let existing = favorites.first(where: { $0.sampleID == s.id }) {
            context.delete(existing)
        } else {
            context.insert(FavoriteReading(sample: s))
            Haptics.success()
        }
    }
}
