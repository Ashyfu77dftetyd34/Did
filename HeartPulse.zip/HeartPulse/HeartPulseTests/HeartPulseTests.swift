import XCTest
@testable import HeartPulse

final class InsightsEngineTests: XCTestCase {
    private func bucket(daysAgo: Int, avg: Double) -> HeartBucket {
        let d = Calendar.current.startOfDay(for: Date().addingTimeInterval(-Double(daysAgo) * 86_400))
        return HeartBucket(date: d, avg: avg, min: avg - 5, max: avg + 5)
    }

    func testNoDataProducesNoInsights() {
        XCTAssertTrue(InsightsEngine.generate(.init()).isEmpty)
    }

    func testRestingIncreaseIsReported() {
        let recent = (0..<5).map { bucket(daysAgo: $0, avg: 66) }
        let previous = (8..<13).map { bucket(daysAgo: $0, avg: 58) }
        let insights = InsightsEngine.generate(.init(restingDaily: recent + previous))
        let resting = insights.first { $0.id == "resting" }
        XCTAssertEqual(resting?.bodyKey, "ins.resting.up")
        XCTAssertEqual(resting?.args.first, 8)
    }

    func testHighAtRestReadingIsFlaggedButActiveIsIgnored() {
        let now = Date()
        let rest = HeartRateSample(id: UUID(), bpm: 135, date: now, source: "Test", context: .sedentary)
        let active = HeartRateSample(id: UUID(), bpm: 170, date: now, source: "Test", context: .active)
        let insights = InsightsEngine.generate(.init(todaySamples: [rest, active], highThreshold: 120))
        let high = insights.first { $0.id == "unusualHigh" }
        XCTAssertEqual(high?.args.first, 1)
        XCTAssertEqual(high?.args.last, 135)
    }

    func testInsightsNeverUseDiagnosticLanguage() throws {
        let path = try XCTUnwrap(Bundle(for: AppSettings.self).path(forResource: "en", ofType: "lproj"))
        let file = path + "/Localizable.strings"
        let dict = try XCTUnwrap(NSDictionary(contentsOfFile: file) as? [String: String])
        for (key, value) in dict where key.hasPrefix("ins.") {
            for banned in ["heart attack", "arrhythmia", "you have", "diagnosed with"] {
                XCTAssertFalse(value.lowercased().contains(banned), "\(key) contains \(banned)")
            }
        }
    }
}

final class TimeRangeTests: XCTestCase {
    func testRangesStartInThePast() {
        let now = Date()
        for r in TimeRange.allCases {
            XCTAssertLessThanOrEqual(r.start(now: now), now)
        }
        XCTAssertEqual(TimeRange.day.restingRange, .week)
    }

    func testFreshnessClassification() {
        let now = Date()
        func s(_ age: TimeInterval) -> HeartRateSample {
            HeartRateSample(id: UUID(), bpm: 70, date: now.addingTimeInterval(-age), source: "T", context: .notSet)
        }
        XCTAssertEqual(Freshness.of(s(30), now: now), .live)
        XCTAssertEqual(Freshness.of(s(600), now: now), .recent)
        XCTAssertEqual(Freshness.of(s(7200), now: now), .recorded)
    }
}

final class LocalizationTests: XCTestCase {
    private func keys(_ lang: String) throws -> Set<String> {
        let path = try XCTUnwrap(Bundle(for: AppSettings.self).path(forResource: lang, ofType: "lproj"))
        let dict = try XCTUnwrap(NSDictionary(contentsOfFile: path + "/Localizable.strings") as? [String: String])
        return Set(dict.keys)
    }

    func testArabicAndEnglishHaveTheSameKeys() throws {
        let en = try keys("en"), ar = try keys("ar")
        XCTAssertEqual(en.subtracting(ar), [], "Missing in Arabic")
        XCTAssertEqual(ar.subtracting(en), [], "Missing in English")
    }
}
